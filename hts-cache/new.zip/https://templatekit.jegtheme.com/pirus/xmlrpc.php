<!DOCTYPE html>
<html lang="en-US">
   <head>
      <title>Access denied</title>
      <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
      <meta name="robots" content="noindex, nofollow" />
      <meta name="viewport" content="width=device-width,initial-scale=1" />
      <link rel="stylesheet" href="/cdn-cgi/styles/errors.css" media="screen" />
      <script>
(function(){if(document.addEventListener&&window.XMLHttpRequest&&JSON&&JSON.stringify){var e=function(a){var c=document.getElementById("error-feedback-survey"),d=document.getElementById("error-feedback-success"),b=new XMLHttpRequest;a={event:"feedback clicked",properties:{errorCode:1020,helpful:a,version:4}};b.open("POST","https://sparrow.cloudflare.com/api/v1/event");b.setRequestHeader("Content-Type","application/json");b.setRequestHeader("Sparrow-Source-Key","c771f0e4b54944bebf4261d44bd79a1e");
b.send(JSON.stringify(a));c.classList.add("feedback-hidden");d.classList.remove("feedback-hidden")};document.addEventListener("DOMContentLoaded",function(){var a=document.getElementById("error-feedback"),c=document.getElementById("feedback-button-yes"),d=document.getElementById("feedback-button-no");"classList"in a&&(a.classList.remove("feedback-hidden"),c.addEventListener("click",function(){e(!0)}),d.addEventListener("click",function(){e(!1)}))})}})();
</script>

      <script>
         (function(){if(document.addEventListener){var c=function(){var b=document.getElementById("copy-label");document.getElementById("plain-ray-id");if(navigator.clipboard)navigator.clipboard.writeText("77160c04589521b7");else{var a=document.createElement("textarea");a.value="77160c04589521b7";a.style.top="0";a.style.left="0";a.style.position="fixed";document.body.appendChild(a);a.focus();a.select();document.execCommand("copy");document.body.removeChild(a)}b.innerText="Copied"};document.addEventListener("DOMContentLoaded",
function(){var b=document.getElementById("plain-ray-id"),a=document.getElementById("click-to-copy-btn");"classList"in b&&(b.classList.add("hidden"),a.classList.remove("hidden"),a.addEventListener("click",c))})}})();
      </script>
      <script defer src="https://performance.radar.cloudflare.com/beacon.js"></script>
   </head>

   <body>
      <div class="main-wrapper" role="main">
         <div class="header section">
            <h1>
               <span class="error-description">Access denied</span>
               <span class="code-label">Error code <span>1020</span></span>
            </h1>
            <div class="large-font">
               <p>You cannot access templatekit.jegtheme.com. Refresh the page or contact the site owner to request access.</p>
            </div>
         </div>
      </div>

      <div>
         <div class="section know-more">
            <h2 class="large-font">Troubleshooting information</h2>
            <p>Copy and paste the Ray ID when you contact the site owner.</p>
            <p class="ray-id-wrapper">
               Ray ID:
               <span class="plain-ray-id" id="plain-ray-id">
                  77160c04589521b7
               </span>
               <button class="click-to-copy-btn hidden" id="click-to-copy-btn" title="Click to copy Ray ID" type="button">
                  <span class="ray-id">77160c04589521b7</span><span class="copy-label" id="copy-label">Copy</span>
               </button>
            </p>
            <p>
            For help visit <a rel="noopener noreferrer" href="https://support.cloudflare.com/hc/articles/360029779472-Troubleshooting-Cloudflare-1XXX-errors?utm_source=1020_error#error1020" target="_blank">Troubleshooting guide</a>
            <img class="external-link" title="Opens in new tab" src="/cdn-cgi/images/external.png" alt="External link">
            </p>
         </div>

         <div class="clearfix footer section" role="contentinfo">
            <div class="column">
               <div class="feedback-hidden py-8 text-center" id="error-feedback">
    <div id="error-feedback-survey" class="footer-line-wrapper">
        Was this page helpful?
        <button class="border border-solid bg-white cf-button cursor-pointer ml-4 px-4 py-2 rounded" id="feedback-button-yes" type="button">Yes</button>
        <button class="border border-solid bg-white cf-button cursor-pointer ml-4 px-4 py-2 rounded" id="feedback-button-no" type="button">No</button>
    </div>
    <div class="feedback-success feedback-hidden" id="error-feedback-success">
        Thank you for your feedback!
    </div>
</div>

            </div>
            <div class="column footer-line-wrapper text-center">
               Performance &amp; security by <a rel="noopener noreferrer" href="https://www.cloudflare.com?utm_source=1020_error" target="_blank">Cloudflare</a>
               <img class="external-link" title="Opens in new tab" src="/cdn-cgi/images/external.png" alt="External link">
            </div>
         </div>
      </div>
   </body>
</html>
